let equipos = ["Recreativo", "Atlético", "Sporting", "Real", "Unión", "Marino",
    "Juventud", "Rayo", "Diocesano", "Deportivo", "Internacional", "Adarve"]
let tablaLocales = rellenarLocales();
let tablaVisitantes = rellenarVisitantes();
let liga = crearLiga();

console.log(tablaLocales);
console.log(tablaVisitantes);
console.log(liga);

function rellenarLocales() {
    let pos = 0;
    let res = [];
    for (let i = 0; i < equipos.length - 1; i++) {
        let subRes = []
        for (let j = 0; j < equipos.length / 2; j++) {
            subRes.push(equipos[pos]);
            if (pos == equipos.length - 2) pos = 0;
            else pos++;
        }
        res.push(subRes);
    }
    return res;
}

function rellenarVisitantes() {
    let pos = equipos.length - 2;
    let res = [];
    for (let i = 0; i < equipos.length - 1; i++) {
        let subRes = [equipos[equipos.length - 1]];
        for (let j = 0; j < equipos.length / 2 - 1; j++) {
            subRes.push(equipos[pos]);
            if (pos == 0) pos = equipos.length - 2;
            else pos--;
        }
        res.push(subRes);
    }
    return res;
}

function crearLiga() {
    let res = [];
    for (let i = 0; i < equipos.length - 1; i++) {
        let jornada = [];
        for (let j = 0; j < equipos.length / 2; j++) {
            if ((Math.random() * 2).toFixed(0) == 1) jornada.push(tablaLocales[i][j] + " vs " + tablaVisitantes[i][j]);
            else jornada.push(tablaVisitantes[i][j] + " vs " + tablaLocales[i][j]);
        }
        res.push(jornada);
    }
    return res;
}
function crearVuelta() {
    for (let i = 0; i < liga.length - 1; i++) {
        let vuelta = [];
        for (let j = 0; j < liga[i].length - 1; j++) {
            let partido = liga[i][j].split(" vs ");
            vuelta.push(partido[1] + " vs " + partido[0]);
            console.log(partido[1] + " vs " + partido[0])
        }
        liga.push(vuelta);
    }
}